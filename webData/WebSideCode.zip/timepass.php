<?php

session_start();
include_once 'conn.php';
define('API_ACCESS_KEY', 'AIzaSyCNHHIgiF3dFLm3yvN_hCxTsIzvvvhtDVU');


    $result1 = mysql_query("SELECT * FROM `DeviceTable`") or die("Error" . mysql_error());
		while ($row2 = mysql_fetch_array($result1)) {
            $var[$i] = array($row2['device_token']);
            $i = $i + 1;
        }

        $msg = array
            (
            'message' => "TIMEPASS"
        );

        $fields = array
            (
            'registration_ids' => array("APA91bHLe168S8bj79KtUvCvQhyNJN2KMpiLeXLS-tPj1EXRuGEH3JJINYkOHKpSijdDUrpBVxyqBEbEV766C6nSJJpeBGVwiZVRL1knEoF9sLKXNdvYkbcKSAT7wNfXFJlbzVUVHojwknM4mHxF37hW7Fm9OTZTIjuZpnN59yuPlUaBgQ2ssZI"),
            'data' => $msg
        );

        $headers = array
            (
            'Authorization: key=' . API_ACCESS_KEY,
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://android.googleapis.com/gcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);

    echo $result;
?>