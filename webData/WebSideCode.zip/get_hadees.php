<?php

include_once 'conn.php';
$count_id = $_REQUEST["id"];
$limit = 50;

$query = "";
if ($count_id == "" || $count_id == "-1") {
    $count_id = 0;
}
$query = "SELECT * FROM `Hadees` WHERE `row_count` >= " . $count_id . " LIMIT 0, ". $limit;

$var = array();
$i = 0;
$result = mysql_query($query) or die("Error" . mysql_error());
while ($row2 = mysql_fetch_array($result)) {
    $var[$i] = array("row_count" => $row2['row_count'], "title" => $row2['title'], "description" => $row2['description'], "reference" => $row2['reference'], "created_on" => $row2['created_on']);
    $i = $i + 1;
}

if ($var == null) {
    echo "NONE";
} else {
    echo json_encode($var);
}
?>