<?php

session_start();
include_once 'conn.php';
define('API_ACCESS_KEY', 'AIzaSyCNHHIgiF3dFLm3yvN_hCxTsIzvvvhtDVU');

$title = $_POST['title'];
$description = $_POST['description'];
$reference = $_POST['reference'];
$created_on = date("Y-m-d");

$title = mysql_real_escape_string($title);
$description = mysql_real_escape_string($description);
$reference = mysql_real_escape_string($reference);

if ($title == "" || $description == "" || $reference == "") {
    echo "All fields are required";
} else {
    $sql = "insert into Hadees (title,description,reference,created_on) values ('$title','$description','$reference', '$created_on')";
    $result = mysql_query($sql) or die("Could not insert data into DB: " . mysql_error());

    $result1 = mysql_query("SELECT * FROM `DeviceTable`") or die("Error" . mysql_error());
    while ($row2 = mysql_fetch_array($result1)) {
        $i = $i + 1;

        $msg = array
            (
            'message' => $title
        );

        $fields = array
            (
            'registration_ids' => array($row2['device_token']),
            'data' => $msg
        );

        $headers = array
            (
            'Authorization: key=' . API_ACCESS_KEY,
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://android.googleapis.com/gcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
        curl_close($ch);
    }

    echo $i." notifications sent";
}
?>