<?php

session_start();
include_once 'conn.php';

$name = $_POST['name'];
$device_token = $_POST['device_token'];

$name = mysql_real_escape_string($name);
$device_token = mysql_real_escape_string($device_token);

if ($device_token == "" || $name == "") {
    echo "ERROR";
} else {
    $sql = "insert into DeviceTable (name,device_token) values ('$name','$device_token')";
    $result = mysql_query($sql) or die("Could not insert data into DB: " . mysql_error());
    echo "DONE";
}
?>