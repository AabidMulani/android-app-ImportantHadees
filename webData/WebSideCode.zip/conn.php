<?php
$host="mysql.hostinger.in";
$user="u535344046_atif";
$pass="atif123456";
$db="u535344046_1";
$con=mysql_connect($host,$user,$pass) or die("unable to connect");
$db=mysql_select_db($db) or die("unable to select db");
?>